# NEXUS AI — بسته آماده انتشار

## سایت
1. این پوشه را در یک مخزن GitHub آپلود کن.
2. در Render گزینه New + → Web Service را بزن و مخزن را وصل کن. فایل `render.yaml` تنظیمات را دارد.
3. در Environment این مقادیر را تنظیم کن: `AI_API_KEY`، `AI_MODEL`، `AI_BASE_URL` و `FLASK_SECRET_KEY`. کلید API را در مخزن عمومی نگذار.
4. پس از Deploy، آدرس سایت Render را کپی کن.

## اپ اندروید
1. بعد از انتشار سایت، فایل `android/app/src/main/java/com/nexusai/app/MainActivity.java` را باز کن.
2. مقدار `SITE_URL` را با آدرس واقعی سایت جایگزین کن (باید با https شروع شود).
3. در GitHub، مخزن را آپلود کن و از بخش Actions گردش‌کار «Build NEXUS AI APK» را اجرا کن.
4. فایل APK در بخش Artifacts همان اجرای workflow قابل دریافت است.

## وضعیت
این بسته پروژهٔ آماده ساخت است، نه APK امضاشده و نه سایت منتشرشده. ساخت APK و انتشار سایت به حساب‌های بیرونی و تنظیم کلید مدل نیاز دارد.
