package com.nexusai.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.View;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    // After deploying the website, replace this with its HTTPS address.
    private static final String SITE_URL = "https://REPLACE-WITH-YOUR-RENDER-SITE.onrender.com";
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,21,43));
        getWindow().setNavigationBarColor(Color.rgb(12,16,32));
        if (SITE_URL.contains("REPLACE-WITH-YOUR-RENDER-SITE")) {
            LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(28,28,28,28); box.setBackgroundColor(Color.rgb(12,16,32));
            TextView title = new TextView(this); title.setText("NEXUS AI"); title.setTextSize(28); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER);
            TextView body = new TextView(this); body.setText("ابتدا سایت NEXUS AI را منتشر کنید و آدرس HTTPS آن را در فایل برنامه قرار دهید؛ سپس APK را بسازید."); body.setTextSize(17); body.setTextColor(Color.LTGRAY); body.setGravity(Gravity.CENTER); body.setPadding(0,24,0,0);
            box.addView(title); box.addView(body); setContentView(box); return;
        }
        web = new WebView(this); WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setLoadsImagesAutomatically(true); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); setContentView(web); web.loadUrl(SITE_URL);
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
