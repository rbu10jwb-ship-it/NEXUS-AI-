import os
import requests
from flask import Flask, request, jsonify, session, render_template_string

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-this-before-public-deployment")
API_KEY = os.getenv("AI_API_KEY", "").strip()
BASE_URL = os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
MODEL = os.getenv("AI_MODEL", "").strip()
ACCESS_CODE = os.getenv("NEXUS_ACCESS_CODE", "").strip()
SYSTEM = 'You are NEXUS AI, a specialist assistant for programming and game development. Respond in Persian by default. Give complete runnable code when practical, explain file names and run steps, and help debug based on actual error logs. Never claim you executed code or created files on the user device unless that actually happened. Prioritize Python, web development, Godot, and Unity.'
PAGE = r'''<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#10152b"><title>NEXUS AI</title>
<style>
:root{color-scheme:dark;--bg:#0c1020;--panel:#151b32;--line:#2a3557;--accent:#7c8cff;--text:#f3f5ff;--muted:#aab3d2}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top,#1c2851,var(--bg) 55%);font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:var(--text);min-height:100vh;display:flex;justify-content:center}.wrap{width:min(900px,100%);min-height:100vh;display:flex;flex-direction:column;padding:16px}.top{display:flex;align-items:center;gap:12px;padding:12px 4px 18px}.logo{width:46px;height:46px;border-radius:15px;background:linear-gradient(135deg,#7c8cff,#39d8c8);display:grid;place-items:center;color:#0b1023;font-weight:900;font-size:21px}.brand{font-size:21px;font-weight:800}.sub{font-size:12px;color:var(--muted)}.status{margin-right:auto;color:#7ce6c4;font-size:12px}.chat{flex:1;display:flex;flex-direction:column;gap:12px;padding:8px 0 18px}.msg{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.8;border:1px solid var(--line);padding:13px 15px;border-radius:18px;max-width:94%}.bot{background:var(--panel);align-self:flex-start}.user{background:#28345e;align-self:flex-end}.welcome{color:var(--muted);text-align:center;margin:auto;line-height:2;padding:30px 10px}.bar{position:sticky;bottom:0;background:#0c1020eF;padding:12px 0 max(12px,env(safe-area-inset-bottom));display:flex;gap:8px}.bar textarea{resize:none;min-height:50px;max-height:140px;flex:1;background:#151b32;border:1px solid var(--line);border-radius:15px;padding:13px;color:var(--text);font:inherit;outline:none}.bar button,.login button{border:0;border-radius:15px;background:var(--accent);color:#10152b;font-weight:800;padding:0 18px;font:inherit;cursor:pointer}.bar button:disabled{opacity:.5}.hint{text-align:center;color:var(--muted);font-size:11px;padding-bottom:8px}.login{max-width:500px;margin:auto;text-align:center;background:var(--panel);border:1px solid var(--line);padding:24px;border-radius:20px}.login input{width:100%;margin:12px 0;background:#0c1020;border:1px solid var(--line);border-radius:12px;padding:13px;color:white;font:inherit}.login button{padding:12px 18px;width:100%}.error{color:#ffaaa9}@media(min-width:700px){.wrap{padding:24px}.msg{max-width:82%}}
</style></head><body><main class="wrap"><header class="top"><div class="logo">N</div><div><div class="brand">NEXUS AI</div><div class="sub">دستیار برنامه‌نویسی و ساخت بازی</div></div><div class="status">● آنلاینِ رابط</div></header>
{% if needs_login %}<section class="login"><h2>ورود به NEXUS AI</h2><p class="sub">کد دسترسی‌ای را وارد کن که در تنظیمات سرور گذاشته شده است.</p><input id="code" type="password" autocomplete="current-password" placeholder="کد دسترسی"><button onclick="login()">ورود</button><p id="loginerr" class="error"></p></section>
<script>async function login(){let code=document.getElementById('code').value;let r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code})});let d=await r.json();if(r.ok)location.reload();else document.getElementById('loginerr').textContent=d.error||'ورود ناموفق بود';}</script>
{% else %}<section id="chat" class="chat"><div class="welcome" id="welcome"><h2>سلام! من NEXUS AI هستم 👋</h2>برای کدنویسی، رفع خطا و ساخت بازی سوالت را بنویس.</div></section><form id="form" class="bar"><textarea id="input" rows="1" placeholder="پیامت را بنویس…" required></textarea><button id="send">ارسال</button></form><div class="hint">کلید API فقط در تنظیمات سرور نگه‌داری شود؛ آن را در چت نفرست.</div>
<script>const chat=document.getElementById('chat'),form=document.getElementById('form'),input=document.getElementById('input'),send=document.getElementById('send');let messages=[];function bubble(text,who){document.getElementById('welcome')?.remove();let d=document.createElement('div');d.className='msg '+who;d.textContent=text;chat.appendChild(d);d.scrollIntoView({behavior:'smooth',block:'end'});return d;}form.addEventListener('submit',async e=>{e.preventDefault();let text=input.value.trim();if(!text)return;input.value='';messages.push({role:'user',content:text});bubble(text,'user');let wait=bubble('دارم فکر می‌کنم…','bot');send.disabled=true;try{let r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages})});let d=await r.json();if(!r.ok)throw Error(d.error||'خطا در دریافت پاسخ');wait.textContent=d.answer;messages.push({role:'assistant',content:d.answer});}catch(err){wait.textContent='خطا: '+err.message;}finally{send.disabled=false;input.focus();}});input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});</script>{% endif %}</main></body></html>'''

@app.get("/")
def index():
    if ACCESS_CODE and not session.get("nexus_ok"):
        return render_template_string(PAGE, needs_login=True)
    return render_template_string(PAGE, needs_login=False)

@app.post("/api/login")
def login():
    if not ACCESS_CODE:
        return jsonify({"error":"کد دسترسی در تنظیمات سرور فعال نشده است."}), 400
    data = request.get_json(silent=True) or {}
    if data.get("code") != ACCESS_CODE:
        return jsonify({"error":"کد اشتباه است."}), 401
    session["nexus_ok"] = True
    return jsonify({"ok": True})

@app.get("/api/status")
def status():
    return jsonify({"configured": bool(API_KEY and MODEL), "access_protected": bool(ACCESS_CODE), "model": MODEL or None})

@app.post("/api/chat")
def chat():
    if ACCESS_CODE and not session.get("nexus_ok"):
        return jsonify({"error":"ابتدا وارد شو."}), 401
    if not API_KEY or not MODEL:
        return jsonify({"error":"هوش مصنوعی هنوز فعال نشده؛ تنظیمات AI_API_KEY و AI_MODEL در سرور لازم است."}), 503
    data = request.get_json(silent=True) or {}
    messages = data.get("messages", [])
    if not isinstance(messages, list) or not messages:
        return jsonify({"error":"پیام خالی است."}), 400
    prepared = [{"role":"system", "content":SYSTEM}]
    for m in messages[-16:]:
        if isinstance(m, dict) and m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str):
            prepared.append({"role":m["role"], "content":m["content"][:10000]})
    try:
        r = requests.post(f"{BASE_URL}/chat/completions", headers={"Authorization":f"Bearer {API_KEY}","Content-Type":"application/json"}, json={"model":MODEL,"messages":prepared,"temperature":0.25}, timeout=90)
        if not r.ok:
            return jsonify({"error":f"سرویس مدل پاسخ نداد (HTTP {r.status_code}). تنظیمات سرور را بررسی کن."}), 502
        return jsonify({"answer":r.json()["choices"][0]["message"]["content"]})
    except requests.Timeout:
        return jsonify({"error":"پاسخ مدل طول کشید؛ دوباره تلاش کن."}), 504
    except Exception:
        return jsonify({"error":"اتصال به مدل ناموفق بود؛ آدرس سرویس و اینترنت سرور را بررسی کن."}), 502

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
